/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;

import java.util.ArrayList;

/**
 *
 * @author jpmal
 */
public class Login {
    // these are my public variables to store value or text
    public    String name;
    public    String password;
    public    String cell_num;
    public    int exit;
    
    
        // this method ensures that the variable "name" meets the condition to store the value
        public boolean checkName() {
            return name !=null && //name must contain something
                   name.length() == 5 && //this ensures that the name should only have 5 characters
                   name.contains("_"); }//this ensures that the name contains an undderscore
        
        // this method ensures that the variable "password" meets the condition to store the value    
        public boolean checkPassword() {
            return password !=null && //password must contain something
                password.length() >= 8 && // this ensures that the password has 8 characters or more
                password.matches(".*[A-Z].*") && // this ensures that the password must contain a Uppercase
                password.matches(".*\\d.*") && // this ensures that the password must contain a number
                password.matches(".*[^A-zA-Z0-9].*"); }// this ensures that the password must contain a special character
        
        // this method ensures that the variable "cell_num" meets the condition to store the value
        public boolean checkCell_num() {
            return cell_num !=null && //must contain something
                   cell_num.startsWith("+27") && //must start with
                   cell_num.matches("\\+27[6-8]\\d{8}") //after "+27 that follows with a 6,7 or 8, eight digits must to be filled in to complete the phone number input
                   ; }
        
        // this method contain the output when the user successfully registered or failed to register
        public String Userdetails() {
            String feedback = ""; // a list
            
            // when the conditions are not met the variable in line 45 accumalates the output response into a list
            if (!checkName()) {
            feedback += "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five charaters in legth\n";
                    }
            if (!checkPassword()) {
                feedback += "Password is not correctly formatted; please ensure that the password conatins at least eight charaters, a capital letter, a number, and a special charater\n";
            }
            if (!checkCell_num()) {
                feedback += "Cellphone number incorrectly formatted or do not contain internation code\n";
                
            }
            if (checkName() && checkPassword() && checkCell_num()) {
                feedback = "Username correct\n";
                feedback += "Password correct\n";
                feedback += "Cellphone number correct\n";
                
        }
            return feedback;// this displays the output
            
        }
        // lists is set to private for security reasons
        private ArrayList<String> names = new ArrayList<>(); // private list for user's registered name
        private ArrayList<String> passwords = new ArrayList<>(); // private list for user's registered password
        private ArrayList<String> PhoneNumbers = new ArrayList<>(); // private list for user's registered phone number
        
        // when conditions are met the variables with the information of the user gets stored in the their respective list
        public void saveDetails() {
            if  (checkName() && checkCell_num() && checkPassword()) {
                names.add(name);
                passwords.add(password);
                PhoneNumbers.add(cell_num);
             
            }
        }
        
        //this method checks for any duplication when registering
        public boolean userExists(String value) {
            return names.contains(value);
           }
        
        //this method checks for any duplication when registering
        public boolean phoneExists(String value) {
            return PhoneNumbers.contains(value);
            }
        
        //this method checks if there are registered users
        public boolean NoUsers () {
            return names.isEmpty();
        
        }
        // this method refers to choice 2 when loging in after registering
        public boolean LoginUser(String inputName, String inputPassword){
        
           for (int i = 0; i < names.size(); i++) { //this is a loop that cycles through the lists of "names" to find the correct registered user 
               if (names.get(i).equals(inputName) && // this checks if the chosen name in the list matches the login name
                   passwords.get(i).equals(inputPassword)) { // this checks if the chosen password in the list matches the login password
                   return true;
               }
           }
           return false;
        }
        // this method refers to the ouput when the user successfully or incorrectly logged in
        public String returnLoginStatus(boolean success) {
            if (success) {
                return "Login successful....Redirecting to chatapp";
            }
            else {
                return "Login failed...Username or Password is incorrect entered..try again";
            }
        }
        }

