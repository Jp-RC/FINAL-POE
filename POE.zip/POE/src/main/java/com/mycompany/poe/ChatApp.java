/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;

import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author jpmal
 */
public class ChatApp {
    Scanner input = new Scanner(System.in); 
    
public int count; 
public String recipient;
public String messageID;
int mesNum = 0;
public String mes;
int totalMesOut = 0;
String[] senders = new String[100]; // THIS STORES USER'S USERNAME FOR RECORD PURPOSES
String[] messageIDs = new String[100]; // THIS STORES THE MESSAGEIDS
String[] recipients = new String[100]; // THIS STORES THE RECIPIENT CONTACT DETAILS WHEN USER STORES THE MESSAGE
String[] messages = new String[100]; // THIS STORES THE MESSAGE CONTACT DETAILS WHEN USER STORES THE MESSAGE
String[] hashes = new String[100]; // THIS STORES THE HASHES WHEN USER STORES THE MESSAGE
String[] disregardMessages = new String[100]; //THIS STORES THE DISREGARDED MESSAGES WHEN USER DISREGARD THE MESSAGE
String[] disregardRecipients = new String[100];// THIS STORES THE DISREGARDED RECEIPIENT WHEN USER DISREGARD THE MESSAGE
String[] disregardHashes = new String[100];// THIS STORES THE DISREGARDED HASHES WHEN USER DISREGARD THE MESSAGE
String[] disregardMessageIDs = new String[100];// THIS STORES THE DISREGARDED MESSAGEIDS WHEN USER DISREGARD THE MESSAGE
String[] SentmessageIDs = new String[100]; // THIS STORES THE MESSAGEIDS
String[] Sentrecipients = new String[100]; // THIS STORES THE RECIPIENT CONTACT DETAILS WHEN USER STORES THE MESSAGE
String[] Sentmessages = new String[100]; // THIS STORES THE MESSAGE CONTACT DETAILS WHEN USER STORES THE MESSAGE
String[] Senthashes = new String[100]; // THIS STORES THE HASHES WHEN USER STORES THE MESSAGE
int messageCount = 0;
int Sentcount = 0;
public String currentUser;
int disregardCount =0;

// THIS IS THE STORED MESSAGE OPTIONS
public void displayStoredMessages() {
    
    System.out.println("1. Display all STORED messages by User");
    System.out.println("2. DIsplay longest message that was Stored or Disregard");
    System.out.println("3. Search Message");
    System.out.println("4. Delete Message");
    System.out.println("5. Full report (STORED MESSAGES & DISREGARDED MESSAGES)");
    System.out.println("6. Back to Main Menu");
    System.out.println("CHOOSE BETWEEN 1 - 6");
    
    
    int choice = input.nextInt();
    input.nextLine();
    
    switch(choice) {
        //THIS OPTION ALLOWS ALL STORED MESSAGES TO APPEAR, EXCLUDING DISREGARDED MESSAGES
        case 1 -> {
            if (messageCount == 0 && Sentcount == 0 && disregardCount == 0) {
            System.out.println("No stored messages found....");
            return;
            }
            for (int i = 0; i < Sentcount; i++) {
            System.out.println("Sent message: "+(i+1));
            System.out.println("Sender: "+senders[i]);
            System.out.println("Recipient: "+ Sentrecipients[i]);
            System.out.println("Message: " + Sentmessages[i]);
            System.out.println("_____________________________");
        }
            for (int i = 0; i < messageCount; i++) {
            System.out.println("Stored message: "+(i+1));
            System.out.println("Sender: "+senders[i]);
            System.out.println("Recipient: "+ recipients[i]);
            System.out.println("Message: " + messages[i]);
            System.out.println("_____________________________");
            }
            for (int i = 0; i < disregardCount; i++) {
            System.out.println("Disregard message: "+(i+1));
            System.out.println("Sender: "+senders[i]);
            System.out.println("Recipient: "+ disregardRecipients[i]);
            System.out.println("Message: " + disregardMessages[i]);
            System.out.println("_____________________________");
            }
        }
        //THIS OPTION ALLOWS THE USER TO DISPLAY THE LONGEST MESSAGE IN EACH ARRAY
        case 2 -> {
            System.out.println("Longest Message: ");
            System.out.println(getLongestMessage());
            }
        
        case 3 -> searchMessageMenu(); //THIS IS ANOTHER MENU FOR THE USER TO SEARCH BY MESSAGEID OR RECIPIENT
        
        case 4 -> deleteMessageByHash();//THIS MENU ALLOWS THE USER TO DELETE THEIR MESSAGES
        
        case 5 -> displayFullReport();// THIS SHOWS A FULL REPORT OF MESSAGES STORED INCLUDING MESSAGES DISREGARDED
        
        case 6 -> {
            return; // THIS ALLOW THE USER TO GO BACK TO THE PREVIOUS MENU
        }
        
    }
}
// THIS METHOD WILL DISPLAY THE LONGEST MESSAGE THAT WAS STORED OR DISREGARDED OR SENT
public String getLongestMessage() {

            if (messageCount == 0 && disregardCount == 0 && Sentcount == 0) {
            return "No messages found...";
            }
            
            String longest ="";
            
            for (int i = 0; i < messageCount; i++) {
                if (messages[i] != null && 
                    messages[i].length() > longest.length()) {
                    
                    longest = messages[i];
                 }
            }
            for (int i = 0; i < disregardCount; i++) {
                if (disregardMessages[i] != null && 
                    disregardMessages[i].length() > longest.length()) {
                    
                    longest = disregardMessages[i];
                 }
            }
            for (int i = 0; i < Sentcount; i++) {
                if (Sentmessages[i] != null && 
                    Sentmessages[i].length() > longest.length()) {
                    
                    longest = Sentmessages[i];
                 }
            }
        return "Longest message: "+ longest;
}

//THIS IS THE SEARCH MENU
public void searchMessageMenu() {
    System.out.println("\nSearch Message");
    System.out.println("1. ...by Message ID?");
    System.out.println("2...by Recipient?");
    System.out.println("3. return to main menu");
     System.out.println("CHOOSE BETWEEN 1 - 3");
    
    
    int choice = input.nextInt();
    input.nextLine();
    
    switch(choice) {
        
        case 1 -> {searchMessageID();}// THIS ALLOWS THE USER SEARCH BY MESSAGE ID
        
        case 2 -> {searchRecipient();}// THIS ALLOWS THE USER SEARCH BY RECIPIENT'S SOUTH AFRICAN CONTACT DETAILS
        
        case 3 -> {
            return; // THIS OPTION ALLOWS THE USER TO GO TO THE MAIN MENU
        }
        
        default -> System.out.println("Invalid option!");
    }

}

// THIS METHOD IS BASED ON THE USER SEARCH BY RECIPIENT
public void searchRecipient(){
    System.out.println("Enter recipient south african number: (+27xxxxxxxxx)");
    String searchRecipient = input.nextLine();
    
    boolean found = false;
    
    // THIS WILL DISPLAY THE DETAILS OF THE SENT MESSAGES OF THE RECIPIENT
    for (int i = 0; i < Sentcount; i++) {
        
        if (Sentrecipients[i].equals(searchRecipient)) {
            
        System.out.println("This message was Sent...");
        System.out.println("Message ID: " + SentmessageIDs[i]);
        System.out.println("Recipient: " + Sentrecipients[i]);
        System.out.println("Message: " + Sentmessages[i]);
        System.out.println("____________________________________");
        
        found = true;
    }
}
    // THIS WILL DISPLAY THE DETAILS OF THE STORED MESSAGES OF THE RECIPIENT
    for (int i = 0; i < messageCount; i++) {
        
        if (recipients[i].equals(searchRecipient)) {
            
        System.out.println("This message was STORED...");
        System.out.println("Message ID: " + messageIDs[i]);
        System.out.println("Recipient: " + recipients[i]);
        System.out.println("Message: " + messages[i]);
        System.out.println("____________________________________");
        
        found = true;
    }
}
    // THIS WILL DISPLAY WHETHER THE USER HAD DISREGARDED MESSAGES OF THE RECIPIENT
    for (int i = 0; i < disregardCount; i++) {
        if (disregardRecipients[i].equals (searchRecipient)) {
        System.out.println("This Message was disregarded...");
        System.out.println("MessageID: " + disregardMessageIDs[i]);
        System.out.println("Recipient: " + disregardRecipients[i]);
        System.out.println("Message: " + disregardMessages[i]);
        System.out.println("____________________________________");
        
        
        found = true;
        }
    }

if (!found) {
    System.out.println("Recipient not found...."); // THIS WILL DISPLAY, ONLY IF THE DETAILS DOES NOT EXIST
    
    }
}

// THIS METHOD ALLOWS THE USER TO DELETE THE MESSAGE BY HASH SEARCH IN THE STORED ARRAY, SENT ARRAY, DISREGARD ARRAY
public void deleteMessageByHash() {

    System.out.println("Enter the Message Hash:");
    String searchHash = input.nextLine();
    
    boolean found = false;
    
    for (int i = 0; i < messageCount; i++) {
        
        if (hashes[i].equals(searchHash)) {
            String deleteMessage = messages[i];
            
            for (int j = i; j < messageCount - 1; j++) {
                
                messageIDs[j] = messageIDs[j+1];
                hashes[j] = hashes[j+1];
                recipients[j] = recipients[j +1];
                messages[j] = messages[j+1];
                senders[j] = senders[j + 1];
            }
            messageCount--;
            
            System.out.println("Message \""+
                    deleteMessage +
                    "\" is successfully deleted..");
            
            found = true;
            return;
        }
    }
    for (int i = 0; i < disregardCount; i++) {
        
        if (disregardHashes[i].equals(searchHash)) {
            String deleteMessage = disregardMessages[i];
            
            for (int j = i; j < disregardCount - 1; j++) {
                
                disregardMessageIDs[j] = disregardMessageIDs[j+1];
                disregardHashes[j] = disregardHashes[j+1];
                disregardRecipients[j] = disregardRecipients[j +1];
                disregardMessages[j] = disregardMessages[j+1];
                
            }
            disregardCount--;
            
            System.out.println("Message \""+
                    deleteMessage +
                    "\" is successfully deleted..");
            
            found = true;
            return;
        }
    }
    for (int i = 0; i < Sentcount; i++) {
        
        if (Senthashes[i].equals(searchHash)) {
            String deleteMessage = Sentmessages[i];
            
            for (int j = i; j < Sentcount - 1; j++) {
                
                SentmessageIDs[j] = SentmessageIDs[j+1];
                Senthashes[j] = Senthashes[j+1];
                Sentrecipients[j] = Sentrecipients[j +1];
                Sentmessages[j] = Sentmessages[j+1];
                
            }
            Sentcount--;
            
            System.out.println("Message \""+
                    deleteMessage +
                    "\" is successfully deleted..");
            
            found = true;
            return;
        }
    }
    if (!found) {
        System.out.println("Message hash not found!"); // THIS WILL DISPLAY WETHER THE DETAILS EXISTS
    }
}

// THIS DISPLAYS ALL THE STORED MESSAGES OF RECIPIENTS AND DISREGARDED MESSAGES AS WELL AS THE SENT MESSAGES
public void displayFullReport() {

    System.out.println("\n+++++++++++ FULL MESSAGE REPORT +++++++++++++");
    System.out.println("_______________________________________________");
    System.out.println("_______________________________________________");
    System.out.println("\n+++++++++++ SENT MESSAGE REPORT +++++++++++++");
    
                
        if (Sentcount == 0) {
            System.out.println("No sent messages found");
        }
        
        else {
        
                for (int i = 0; i < Sentcount; i++) {
            System.out.println("\nMessage " + (i + 1));
            System.out.println("Sender: " + senders[i]); //include senders
            System.out.println("Message ID: " + SentmessageIDs[i]);
            System.out.println("Message Hash: " + Senthashes[i]);
            System.out.println("Recipient: " + Sentrecipients[i]);
            System.out.println("Message: " + Sentmessages[i]);
            
            System.out.println("_________________________________________");
        }
    }
    System.out.println("\n+++++++++++ STORED MESSAGE REPORT +++++++++++++");
                
        if (messageCount == 0) {
            System.out.println("No stored messages found");
        }
        
        else {
        
                for (int i = 0; i < messageCount; i++) {
            System.out.println("\nMessage " + (i + 1));
            System.out.println("Sender: " + senders[i]); //include senders
            System.out.println("Message ID: " + messageIDs[i]);
            System.out.println("Message Hash: " + hashes[i]);
            System.out.println("Recipient: " + recipients[i]);
            System.out.println("Message: " + messages[i]);
            
            System.out.println("_________________________________________");
        }
    }
        System.out.println("\n+++++++++++ DISREGARDED MESSAGE +++++++++++++");
        
        if (disregardCount == 0) {
            System.out.println("No disregarded messages");
        }
        else {
            for (int i = 0; i < disregardCount; i++) {
                System.out.println("Disregarded Message " + (i + 1));
                System.out.println("Sender: " + senders[i]); //include senders
                System.out.println("MessageID's: " + disregardMessageIDs[i]);
                System.out.println("Message Hash: " + disregardHashes[i]);
                System.out.println("Recipient: " + disregardRecipients[i]);
                System.out.println("Message: " + disregardMessages[i]);
                System.out.println("___________________________________");
            }
        }
}
// THIS METHOD ALLOWS THE USER TO SEARCH BY MESSAGEID
public void searchMessageID(){
    System.out.println("Enter Message ID:");
    String searchID = input.nextLine();
    
    boolean found = false;
    
     for (int i = 0; i < Sentcount; i++) {
        
        if (SentmessageIDs[i].equals(searchID)) {
    
        System.out.println("This message was SENT...");
        System.out.println("Message ID: " + SentmessageIDs[i]);
        System.out.println("Recipient: " + Sentrecipients[i]);
        System.out.println("Message: " + Sentmessages[i]);
        
        found = true;
    }
}
    
    for (int i = 0; i < messageCount; i++) {
        
        if (messageIDs[i].equals(searchID)) {
    
        System.out.println("This message was STORED...");
        System.out.println("Message ID: " + messageIDs[i]);
        System.out.println("Recipient: " + recipients[i]);
        System.out.println("Message: " + messages[i]);
        
        found = true;
    }
}
    // THIS WILL DISPLAY WHETHER THE USER HAD DISREGARDED MESSAGES OF THE RECIPIENT
    for (int i = 0; i < disregardCount; i++) {
        if (disregardMessageIDs[i].equals (searchID)) {
        System.out.println("This Message was disregarded...");
        System.out.println("Recipient: " + disregardRecipients[i]);
        System.out.println("Message: " + disregardMessages[i]);
        
        found = true;
        }
    }

if (!found) {
    System.out.println("Message ID not found....");// THIS ONLY DISPLAY WHETHER THE DETAILS EXISTS
    
    }
}

//THIS METHOD WILL GENERATE A RANDOM NUMBER ON A MESSAGEID 
public static String generateMessageID() {
return String.format("%010d",
        new Random().nextInt(1_000_000_000));
}

//ONCE THE USER CLICK "SEND" THIS METHOD WILL DISPLAY THE DETAILS OF THE MESSAGE SENT OUT
public static void displayMessageDetails(String id, String hash, String recipient, String message) {
System.out.println("\nMessage Details");
System.out.println("Message ID: " + id);
System.out.println("Hash: " + hash);
System.out.println("Recipient: " + recipient);
System.out.println("Message: " + message);
}

//THIS METHOD ASKS THE USER HOW MANY MESSAGES DOES HE/SHE WANT TO SEND 
public void sendMessages() {
    
    System.out.println("What is the total amount of messages you would like to send");
    count = input.nextInt();
    input.nextLine();
    
    for (int i = 0;i < count; i++) {
        mesNum++;
        
        messageID = generateMessageID();
        
        System.out.println("Enter the reciever's phone number (+27)"); // THIS IS WHERE THE USER TYPES IN THE RECIPIENT'S SOUTH AFRICAN CONTACT DETAILS
        recipient =input.nextLine();
        
        if(!recipient.matches("^\\+27\\d{9}$")) {
            System.out.println("Invalid input");
            i--;
            continue;
        }
        System.out.println("Enter message (250 max characters)");
        mes = input.nextLine();
        
        if (mes.length()>250) {
            System.out.println("Message too long by "+ (mes.length()-250)+" charaters.");
            i--;
            continue;
        
        }
    
        //THIS MENU ASK WHAT THE USER WANT TO DO WITH THE MESSAGE(S)
        String hush = generateMessageHash (messageID, mesNum, mes);
            
            System.out.println("What do you want to do?");
            System.out.println("1. Send");
            System.out.println("2. Disregard");
            System.out.println("3. Store");
            
            int action = input.nextInt();
            input.nextLine();
            
            switch (action) {
                case 1 -> { //THIS ALLOWS THE USER TO SEND THE MESSAGE
                    totalMesOut++;
                    Sentmessages[Sentcount] = mes;
                    Sentrecipients[Sentcount] = recipient;
                    Senthashes[Sentcount]=hush;
                    SentmessageIDs[Sentcount]=messageID;
                    Sentcount++;
                    
                StringBuilder jsonEntry = new StringBuilder();
                jsonEntry.append("{\n");//open to store
                
                jsonEntry.append("\n");
                jsonEntry.append("\"Status\": \"Sent\",\n");
                
                jsonEntry.append("\n");
                jsonEntry.append("\"MessageID\": \"")
                         .append(messageID)
                         .append("\",\n");
                
                jsonEntry.append("\n");
                jsonEntry.append("\"Sender\": \"")
                         .append(currentUser)
                         .append("\",\n");
                
                jsonEntry.append("\"MessageHash\": \"")
                         .append(hush)
                         .append("\",\n");
                
                jsonEntry.append("\"Recipient\": \"")
                         .append(recipient)
                         .append("\",\n");
                
                jsonEntry.append(" \"Message\": \"")
                         .append(mes.replace("\"", "\\\""))
                         .append("\"\n");
                         
                jsonEntry.append("},\n");
                
                try (FileWriter file = new FileWriter("MessageBank.json", true)) {
                    file.write(jsonEntry.toString());
                    
                    displayMessageDetails(messageID, hush, recipient,mes);
                    
                    System.out.println("Message successfully sent .... Good job");
                    
                          }
                catch (IOException e) {
                    System.out.println("Error has occurred when writing file: " 
                            + e.getMessage());
                    
                           }
                }
                case 2 -> {// THIS DISREGARD THE MESSAGE HOWEVER IT ALSO STORES THE DISREGRADED RECIPIENT AND DISREGARDED MESSAGE IN AN ARRAY
                    disregardMessages[disregardCount] = mes;
                    disregardRecipients[disregardCount] = recipient;
                    disregardHashes[disregardCount]=hush;
                    disregardMessageIDs[disregardCount]=messageID;
                    disregardCount++;
                    System.out.println("Message has been disregarded and not sent to the reciever....");
                    
                StringBuilder jsonEntry = new StringBuilder();
                jsonEntry.append("{\n");//open to store
                
                jsonEntry.append("\n");
                jsonEntry.append("\"Status\": \"Disregard\",\n");
                
                jsonEntry.append("\n");
                jsonEntry.append("\"MessageID\": \"")
                         .append(messageID)
                         .append("\",\n");
                
                jsonEntry.append("\n");
                jsonEntry.append("\"Sender\": \"")
                         .append(currentUser)
                         .append("\",\n");
                
                jsonEntry.append("\"MessageHash\": \"")
                         .append(hush)
                         .append("\",\n");
                
                jsonEntry.append("\"Recipient\": \"")
                         .append(recipient)
                         .append("\",\n");
                
                jsonEntry.append(" \"Message\": \"")
                         .append(mes.replace("\"", "\\\""))
                         .append("\"\n");
                         
                jsonEntry.append("},\n");
                
                try (FileWriter file = new FileWriter("MessageBank.json", true)) {
                    file.write(jsonEntry.toString());
                    
                          }
                catch (IOException e) {
                    System.out.println("Error has occurred when writing file: " 
                            + e.getMessage());
                    
                           }
                }
                case 3 -> {// THIS STORES THE MESSAGE IN JSON FILE AND AN ARRAY
                    storeMessage(messageID,hush,recipient,mes);
                            System.out.println("Message has been stored");
                           }
        
        }
    }
}
// THIS ALLOW THE USER TO GENERATE A MESSAGE HASH
            public static String generateMessageHash(String id, int num, String msg){
                String[] words = msg.trim().split(" ");
                
                String first = words[0];
                String last = words[words.length-1];
                
                return (id.substring(0,2)+":"+ num +":" + first + last).toUpperCase();
                           }
            
            //Messages are stored in a JSON FILE AND IN ARRAY
            public void storeMessage(String messageID, String hash, String recipient, String message) {
                    messageIDs[messageCount]=messageID;
                    hashes[messageCount]=hash;
                    senders[messageCount]=currentUser;
                    recipients[messageCount]=recipient;
                    messages[messageCount]=message;
                    messageCount++;
                    
                StringBuilder jsonEntry = new StringBuilder();
                jsonEntry.append("{\n");//open to store
                
                jsonEntry.append("\n");
                jsonEntry.append("\"Status\": \"Stored\",\n");
                
                jsonEntry.append("\n");
                jsonEntry.append("\"MessageID\": \"")
                         .append(messageID)
                         .append("\",\n");
                
                jsonEntry.append("\n");
                jsonEntry.append("\"Sender\": \"")
                         .append(currentUser)
                         .append("\",\n");
                
                jsonEntry.append("\"MessageHash\": \"")
                         .append(hash)
                         .append("\",\n");
                
                jsonEntry.append("\"Recipient\": \"")
                         .append(recipient)
                         .append("\",\n");
                
                jsonEntry.append(" \"Message\": \"")
                         .append(message.replace("\"", "\\\""))
                         .append("\"\n");
                         
                jsonEntry.append("},\n");
                
                try (FileWriter file = new FileWriter("MessageBank.json", true)) {
                    file.write(jsonEntry.toString());
                    
                          }
                catch (IOException e) {
                    System.out.println("Error has occurred when writing file: " 
                            + e.getMessage());
                          }
                }
}



