/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe;
import java.util.Scanner;

/**
 *
 * @author jpmal
 */
public class POE {

    public static void main(String[] args) {
    Scanner input = new Scanner(System.in); // named the scanner as "input"
    Login u = new Login(); // shorten the java class to "u"
    boolean running = true;
    ChatApp c = new ChatApp();
        OUTER:
        while (running) {
            System.out.print("Welcome to the Chatapp");
            System.out.print("\nMain Menu:");
            System.out.println("\n1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("choose between 1 - 3");
            int choice = input.nextInt();
            input.nextLine();
            //Register
            switch (choice) {
                case 1 -> {
                    // user must input his details accordingly
                    System.out.println("Please enter your username (ensure that the name is five charaters in length with an underscore included)");
                    u.name = input.nextLine();
                    System.out.println("Please enter your password (ensure more than 8 charaters in length, contains an Uppercase, a number and special characters)");
                    u.password = input.nextLine();
                    System.out.println("Please enter your Cellphone number that starting with South Africa's International code with a plus + (e.g +27)");
                    u.cell_num = input.nextLine();
                    //at the user completes his registration, the results various whether the input was correct or  incorrect
                    String Results = u.Userdetails();
                    System.out.println(Results);
                    // if any of the users input is incorrect, the user gets taken back to the main menu to start over
                    if (!u.checkCell_num()|| !u.checkName() || !u.checkPassword()) {
                        System.out.println("Try again....");
                    }       // this displays the when the user is registerred already
                    if (u.userExists(u.name) || u.phoneExists(u.cell_num)){
                        System.out.println("Users details already exists");
                        continue;
                    }           // once the conditions has been met, i call upon this statement to save the users details in their respective lists
                    if (u.checkCell_num() && u.checkName() && u.checkPassword()) {
                        System.out.println("Your information has been saved, please proceed to the login page");
                        u.saveDetails();
                    }
                }
                case 2 -> {
                    if (u.NoUsers()) {
                        System.out.println("No users has registered");//this displays when there are no registered users yet
                        continue;
                    }           //after registration is a success, they then need to Log in with their registered details
                    System.out.println("Enter username:");
                    String LoginUse = input.nextLine();
                    System.out.println("Enter password:");
                    String LoginPass = input.nextLine();
                    //the details then gets put into a method to see if the correct details was used
                    boolean LoginSuccess = u.LoginUser(LoginUse, LoginPass);
                    String output = u.returnLoginStatus(LoginSuccess);
                    System.out.println(output);//depending on the outcome the message will display whether the user logged in successful or incorrectly 
                    while (LoginSuccess==true) {   //this menu only appears if the User's Login details are correct
                        c.currentUser = LoginUse;
                        System.out.println("Welcome to Quickchat!!!!");
                        System.out.println("1. Send Messages");
                        System.out.println("2. Coming Soon");
                        System.out.println("3. Stored Message");
                        System.out.println("4. Quit/Exit");
                        System.out.println("Choose an option between 1 - 4 ");
                        
                        int option = input.nextInt();
                        input.nextLine();
                        
                        switch(option) {
                            case 1 -> {c.sendMessages();// THIS ALLOWS THE USER TO SEND OR DISREGARD OR STORE THE MESSAGE
                            }
                            case 2 -> {
                                System.out.println("Coming Soon");// OPTION IS NOT AVALAIBLE
                            }
                            case 3 -> { c.displayStoredMessages();// THIS TAKES THE USER TO THE STORED MESSAGE MENU
                            }
                            case 4 -> 
                            {
                             System.out.println("Thank you for using the app...."); //THIS OPTION ALLOWS THE USER TO STOP USING THE APP
                             break OUTER;
                                }
                            }
                        }
                }
                case 3 -> {
                    System.out.println("Are you sure...you would like to exit??");
                    System.out.println("1. YES");
                    System.out.println("2. NO");
                    System.out.println("choose between 1 - 2");
                    u.exit = input.nextInt();
                    input.nextLine();//to eleminate any left over enters
                    switch (u.exit) {
                        case 1 -> {
                            System.out.println("Thank you for using the App");
                            break OUTER; //this stops the loop when the user presses 1. for yes
                    }
                        case 2 -> System.out.println("Proceeding back to the main menu....");//if "no", the user gets taken back to the menu
                        default -> System.out.println("Incorrect command try again....."); //an acidental type a number above 2 that would take you back to the main menu to try again
                    }
                }

                default -> System.out.println("Incorrect command try again....."); //an acidental type a number above 3 that would take you back to the main menu to try again
            }
        }
        }
    }