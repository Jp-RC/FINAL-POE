/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author jpmal
 */
public class LoginIT {
    
    public LoginIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testCheckName() {
        System.out.println("checkName");
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkName();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testCheckPassword() {
        System.out.println("checkPassword");
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkPassword();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testCheckCell_num() {
        System.out.println("checkCell_num");
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkCell_num();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testUserdetails() {
        System.out.println("Userdetails");
        Login instance = new Login();
        String expResult = "";
        String result = instance.Userdetails();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testSaveDetails() {
        System.out.println("saveDetails");
        Login instance = new Login();
        instance.saveDetails();
        fail("The test case is a prototype.");
    }

    @Test
    public void testUserExists() {
        System.out.println("userExists");
        String value = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.userExists(value);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testPhoneExists() {
        System.out.println("phoneExists");
        String value = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.phoneExists(value);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testNoUsers() {
        System.out.println("NoUsers");
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.NoUsers();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testLoginUser() {
        System.out.println("LoginUser");
        String inputName = "";
        String inputPassword = "";
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.LoginUser(inputName, inputPassword);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean success = false;
        Login instance = new Login();
        String expResult = "";
        String result = instance.returnLoginStatus(success);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }
    
}
