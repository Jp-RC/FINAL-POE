/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author jpmal
 */
public class ChatAppIT {
    
    public ChatAppIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    //Tested 1 and 4 messages in the correct messages array is working
    @Test
    public void testDisplayStoredMessages() {
        ChatApp c = new ChatApp();
        
        c.currentUser = "jprm_";
        c.Sentmessages[0]="Did you get the cake?";
        c.Sentmessages[1]="It is dinner time !";

        assertEquals("Did you get the cake?", c.Sentmessages[0]);
        assertEquals("It is dinner time !", c.Sentmessages[1]);
        
        
        
    }

    @Test
    public void testSearchMessageMenu() {
        System.out.println("searchMessageMenu");
        ChatApp instance = new ChatApp();
        instance.searchMessageMenu();
        fail("The test case is a prototype.");
    }
// this test if the correct recipient was found
    @Test
    public void testSearchRecipient() {
        ChatApp c = new ChatApp();
        c.recipients[0]="+27838884567";
        c.recipients[1]="+27838884567";
        c.messageIDs[0]="1234567890";
        c.messageIDs[1]="1357902648";
        c.messages[0]="Where are you? You are late! I have asked you to be on time.";
        c.messages[1]="Ok, I am leaving without you";
        c.messageCount =2;
        c.input = new Scanner("+27838884567");
        c.searchRecipient();
        assertEquals("+27838884567",c.recipients[0]);
        assertEquals("+27838884567",c.recipients[1]);
        
        
    }
// this test if the message does delete
    @Test
    public void testDeleteMessageByHash() {
        ChatApp c = new ChatApp();
        c.messageCount=1;
        c.hashes[0]="13:1:EATSOMERICE";
        c.messages[0]="Where are you? You are late! I have asked you to be on time.";
        
        c.input = new Scanner("13:1:EATSOMERICE\n");
        
        c.deleteMessageByHash();
        
        assertEquals(0, c.messageCount);
    }
// this test checks if the method displays the users full report of stored messages including the disregarded messages
    @Test
    public void testDisplayFullReport() {
     ChatApp c = new ChatApp();
     
     c.senders[0]="jprm_";
     c.messages[0]="Ok, I am leaving without you.";
     c.recipients[0]="+27838884567";
     c.hashes[0]="13:1:EATSOMERICE";
     c.messageIDs[0]="1234567890";
     c.messageCount = 1;
     
     c.displayFullReport();
     
     assertEquals("Ok, I am leaving without you.",c.messages[0]);
     assertEquals("+27838884567",c.recipients[0]);
     assertEquals("13:1:EATSOMERICE",c.hashes[0]);
     assertEquals("1234567890",c.messageIDs[0]);
     assertEquals("jprm_",c.senders[0]);
    }
//checks if the messages that is search through MessageID is true
    @Test
    public void testSearchMessageID() {
        ChatApp c = new ChatApp();
        c.SentmessageIDs[0]="1234567890";
        c.Senthashes[0]="13:1:EATSOMERICE";
        c.Sentmessages[0]="It is dinner time!";
        c.Sentrecipients[0]="+27838884567";
        c.Sentcount = 1;
        
        c.input = new Scanner("1234567890");
        c.searchMessageID();
        
        assertEquals("1234567890",c.SentmessageIDs[0]);
    
    }

    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        String expResult = "";
        String result = ChatApp.generateMessageID();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testDisplayMessageDetails() {
        System.out.println("displayMessageDetails");
        String id = "";
        String hash = "";
        String recipient = "";
        String message = "";
        ChatApp.displayMessageDetails(id, hash, recipient, message);
        fail("The test case is a prototype.");
    }

    @Test
    public void testSendMessages() {
        System.out.println("sendMessages");
        ChatApp instance = new ChatApp();
        instance.sendMessages();
        fail("The test case is a prototype.");
    }

    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = "";
        int num = 0;
        String msg = "";
        String expResult = "";
        String result = ChatApp.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    @Test
    public void testStoreMessage() {
        System.out.println("storeMessage");
        String messageID = "";
        String hash = "";
        String recipient = "";
        String message = "";
        ChatApp instance = new ChatApp();
        instance.storeMessage(messageID, hash, recipient, message);
        fail("The test case is a prototype.");
    }
//this test if the longest message is true
    @Test
    public void testGetLongestMessage() {
       ChatApp c = new ChatApp();
    c.messageCount = 1;
    c.disregardCount = 1;
    c.Sentcount = 1;
    
    c.messages[0] = "Where are you? You are late! I have asked you to be on time.";
    c.disregardMessages[0] = "Yohooo, I am at your gate.";
    c.Sentmessages[0]= "Did you get the cake?";
    
    assertEquals("Longest message: Where are you? You are late! I have asked you to be on time.",c.getLongestMessage());
    }
    
}
